<link rel="stylesheet" href="https://unpkg.com/bootstrap-darkmode@0.7.0/dist/darktheme.css"/>
<script src="https://unpkg.com/bootstrap-darkmode@0.7.0/dist/theme.js"></script>
<script>

const themeConfig = new ThemeConfig();
// place customizations here
themeConfig.initTheme();
</script>

<div class="col-lg-8 mx-auto p-3 py-md-5">
			<header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
      <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
        <span class="fs-4"><?php echo $_SESSION["headerLogo"]; ?></span>
      </a>

      <ul class="nav nav-pills">
        <li class="nav-item"><a href="../" class="nav-link">Back to menu</a></li>
      </ul>
    </header>
    </a>
  </header>