<html>
  <head>
    <title>Premium Naughts and Crosses</title>
		<link rel="stylesheet" href="css/index.css"></link>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
  </head>
  <body>
			<?php require('screenselector.php');?>
		<script src="js/index.js"></script>
  
	
<footer class="footer mt-auto py-3 bg-light" style="bottom: 0; position: absolute;">
  <div class="container">
    <span class="text-muted">Developed by Charlie McMahon. © 2021. <a href="https://www.macca.xyz" target="_blank" style="color: gray;">Website</a></span>
  </div>
</footer>
	
	</body>
</html>