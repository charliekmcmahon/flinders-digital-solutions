<?php
$winningMoves = array(
	// The possible winning combinations
	array(1,2,3),
	array(4,5,6),
	array(7,8,9),
	array(1,4,7),
	array(2,5,8),
	array(3,6,9),
	array(1,5,9),
	array(3,5,7)
);
?>