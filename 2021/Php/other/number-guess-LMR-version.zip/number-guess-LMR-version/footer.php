<?php 

session_start();
echo '<p class=""> Copyright &copy; Charlie McMahon - ABN 101100102'.$_SESSION["number_to_guess"];

?>